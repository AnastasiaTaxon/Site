<?php

set_time_limit(600);
error_reporting(E_ALL);

$logging = false;
$log = "";
$type = "GET";
$url = $_GET["uri"];
$parse = parse_url($url);
$host = $parse["host"];
$domain = "siriusxm.com";

if (substr($host, -strlen($domain)) !== $domain)
{
	exit("Invalid Host Domain: " + $host);
}

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLINFO_HEADER_OUT, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 600);
curl_setopt($ch, CURLOPT_FAILONERROR, true);

$requestHeaders = getallheaders();
$headers = array();

foreach ($requestHeaders as $key => $value)
{
	if (strpos($key, "Accept") === false && strpos($key, "Host") === false)
	{
		$headers[] = "$key: $value";
	}
}

$rawdata = file_get_contents("php://input");

if (!empty($rawdata))
{
	$type = "POST";
	$headers[] = "Content-Type: text/plain";

	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $rawdata);
}

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

log_data($type." REQUEST ========================================================================");
log_data(date("Y-m-d H:i:s"));
log_data($url);
log_data("HEADERS", array_to_string($requestHeaders));

if ($type == "POST")
{
	log_data("BODY", $rawdata);
}

$response = curl_exec($ch);

if (curl_errno($ch) > 0)
{
	//Add error-handling for this on the client side
	echo "Curl error: ".curl_error($ch);
}
else
{
	log_data($type." RESPONSE =======================================================================");
	log_data(date("Y-m-d H:i:s"));
	log_data($url);

	$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
	$header = substr($response, 0, $header_size);
	$body = substr($response, $header_size);

	log_data("HEADER", $header);
	log_data("BODY", $body);

	set_headers($header);
	set_cookies($header);

	if ($logging)
	{
		file_put_contents("log.txt", $log, FILE_APPEND);
	}

	header("Content-type: ".curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
	print_r($body);
}

// close cURL resource, and free up system resources
curl_close($ch);

function array_to_string($array)
{
	$output = "";

	foreach ($array as $key => $value)
	{
		$output .= $key.": ".$value."\n";
	}

	return $output;
}

function log_data($caption, $data = null)
{
	global $logging, $log;

	if ($logging)
	{
		if (!is_null($data))
		{
			$caption .= ":\n\n".$data;
		}

		$log .= $caption."\n\n";
	}
}

function set_cookies($header)
{
	$matches = array();
	preg_match_all("/Set-Cookie:(?<cookie>\s{0,}.*)$/im", $header, $matches);

	foreach ($matches["cookie"] as $item)
	{
		$items = explode(";", trim($item));
		$cookie = explode("=", $items[0]);
		$expires = 0;

		foreach ($items as $part)
		{
			$parts = explode("=", trim($part));

			if ($parts[0] == "Expires")
			{
				$expires = strtotime($parts[1]);
				$maxTime = strtotime("+1 year");

				if ($expires > $maxTime)
				{
					$expires = $maxTime;
				}
			}
		}
		setcookie($cookie[0], rawurldecode($cookie[1]), $expires);
	}
}

function set_headers($header)
{
	$headers = explode("\n", $header);

	foreach ($headers as $headerLine)
	{
		if (stripos($headerLine, "X-Mountain-Notification") !== false ||
			stripos($headerLine, "CrossDevicePausePointTime") !== false)
		{
			header($headerLine);
		}
	}
}

?>